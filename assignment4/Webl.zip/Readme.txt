WebL VERSION 3.0

This readme gives instructions for installing WebL and running WebL scripts.
The WebL user manual in the "webl.pdf" describes the system fully.

More information about the software can be obtained from the WebL
web site at:

	http://www.compaq.com/WebL

An electronic mailing list is available for discussing WebL. You may send
a message to "webl-request@src-mail.pa.dec.com" for instructions how
to subscribe to the list.


INSTALLATION REQUIREMENTS

A Java Development Kit (JDK) version 1.1 or later,
or a Java Runtime Environment (JRE) version 1.1 or later.
Free versions of the JDK software can be downloaded from
http://www.javasoft.com.

Adobe Acrobat for reading the WebL user manual. Free versions
of Acrobat can be downloaded from http://www.adobe.com.


INSTALLATION INSTRUCTIONS

1. Unpack downloaded archive in an empty directory.

2. Windows 95/NT only:

   Make sure that ALL .dll files part of the distribution are accessible from your
   Java runtime. This can be accomplished by copying these files to
   ONE of the following directories (these directories are typically searched by
   the installed Java VM):

	java/bin
	\Winnt\System  (Windows NT only)
	\Windows\System  (Windows 95 & 98)

3. If you are behind an Internet firewall/proxy:

	Most stand-alone JVM configurations do not have any proxies configured, which
	means that WebL can only access your Intranet. You may configure your proxy
	settings by creating a file called "webl.properties" with the following content
	in the WebL installation directory. Don't forget to change the proxy host, port,
	and non-proxy hosts to reflect those of your proxy.

------------- File webl.properties   Cut here -----------------
#
# webl.properties
#

http.proxySet=true
http.proxyHost=www-proxy.yourcompany.com
http.proxyPort=8080
http.nonProxyHosts=*.yourcompany.com

ftpProxySet=true
ftpProxyHost=www-proxy.yourcompany.com
ftpProxyPort=8080
ftpNonProxyHosts=*.yourcompany.com

------------- Cut here -----------------


RUNNING WEBL PROGRAMS

WebL runs as a stand-alone Java program.

Running a WebL program is highly dependent on the hosting platform. The WebL
classes and resources are bundled in a Java JAR file called WebL.jar. The
main class in this JAR file is called WebL.class. The main method of this
class needs to be executed with the following arguments:

    {options} filename [arg1 arg2 ... ]

The options are summarized in Table 1. The filename argument specifies the
name of webl program to be executed, and arg1, arg2, etc. are the arguments
passed to the WebL program. The latter argument list can be accessed from the
variable called ARGS inside WebL programs. The following list gives an
indication of how WebL programs can be executed depending on one of several
Java installation scenarios:

    Java development kit:
    	java WebL {options} filename [arg1 arg2 ...]

    Java Runtime Environment (JDK 1.1):
    	jre -cp WebL.jar WebL {options} filename [arg1 arg2 ...]

    JDK 1.2 beta version with extension support:
    	java -new -jar WebL.jar {options} filename [arg1 arg2 ...]

	Java 2 (a.k.a JDK 1.2):
		java -jar WebL.jar {options} filename [arg1 arg2 ...]


TABLE 1: WebL Command Line Options

    Option	    Description
    -D	        Emit casual debugging output.
    -Llogfile	Write casual debugging output to a log file.
    -C	        Print performance counters at end of run.
    -P	        Wait for ENTER when the program finishes.


LICENSE

WebL is distributed under a free commercial use license, 
as described in more detail in the file "License.txt" 
distributed with this software.

This software contains regular expression software developed by
Daniel F. Savarese. Copyright (c) 1997-1999 by Daniel F. Savarese.
All rights reserved.


CONTACT

Hannes Marais
Compaq Computer Corporation
Systems Research Center
130 Lytton Avenue
Palo Alto, CA 94301

e-mail: marais@pa.dec.com
home: http://www.research.digital.com/SRC/personal/Johannes_Marais/home.html
